# -*- coding: utf-8 -*-
#from __future__ import absolute_import, unicode_literals
import os
import csv
import sys
from PIL import Image
import random
import time
import urllib2
import requests
import jellyfish            # import for calculating similarity in alternate text
#from skimage.measure import structural_similarity as ssim


proxies = {
  'http': 'http://10.10.80.12:3128',
  'https': 'http://10.10.80.12:3128',
}

DIST = 8



def normalize_pixel(r, g, b):
    """
    pixel color normalize
    :param r: int
    :param g: int
    :param b: int
    :return: (int, int, int)
    """
    if is_modify_pixel(r, g, b):
        seed = random.randint(1, 3)
        if seed == 1:
            r = _normalize(r)
        if seed == 2:
            g = _normalize(g)
        if seed == 3:
            b = _normalize(b)
    return r, g, b


def modify_pixel(r, g, b):
    """
    pixel color modify
    :param r: int
    :param g: int
    :param b: int
    :return: (int, int, int)
    """
    return map(_modify, [r, g, b])


def is_modify_pixel(r, g, b):
    """
    :param r: int
    :param g: int
    :param b: int
    :return: bool
    """
    return r % DIST == g % DIST == b % DIST == 1


def _modify(i):
    if i >= 128:
        for x in xrange(DIST + 1):
            if i % DIST == 1:
                return i
            i -= 1
    else:
        for x in xrange(DIST + 1):
            if i % DIST == 1:
                return i
            i += 1
    raise ValueError


def _normalize(i):
    if i >= 128:
        i -= 1
    else:
        i += 1
    return i


def normalize(path, output):
    """
    normalize image
    :param path: str
    :param output: str
    """
    img = Image.open(path)
    img = img.convert('RGB')
    size = img.size
    new_img = Image.new('RGB', size)

    for y in range(img.size[1]):
        for x in range(img.size[0]):
            r, g, b = img.getpixel((x, y))
            _r, _g, _b = normalize_pixel(r, g, b)
            new_img.putpixel((x, y), (_r, _g, _b))
    new_img.save(output, "PNG", optimize=True)


def hide_text(path, text):
    
    text = str(text)

    # convert text to hex for write
    write_param = []
    _base = 0
    for _ in to_hex(text):
        write_param.append(int(_, 16) + _base)
        _base += 16

    # hide hex-text to image
    img = Image.open(path)
    counter = 0
    for y in range(img.size[1]):
        for x in range(img.size[0]):
            if counter in write_param:
                r, g, b = img.getpixel((x, y))
                r, g, b = modify_pixel(r, g, b)
                img.putpixel((x, y), (r, g, b))
            counter += 1

    # save
    img.save(path, "PNG", optimize=True)


def to_hex(s):
    return s.encode("hex")


def to_str(s):
    return s.decode("hex")
###############################################################################################################


def read_text(path):
  try:
    img = Image.open(path)
    counter = 0
    result = []
    counter = 0
    result = []
    for y in range(img.size[1]):
        for x in range(img.size[0]):
            r, g, b = img.getpixel((x, y))
            if is_modify_pixel(r, g, b):
                result.append(counter)
            counter += 1
            if counter == 16:
                counter = 0
    return to_str(''.join([hex(_)[-1:] for _ in result]))
  except TypeError:  # Handle error while reading an image which was not encoded.
    return " "


# Main program
def main():

    print("Start Encode")
    f1 = open ("images_alt_dataset.csv","r") #images_alt_dataset
    #users_dict = {}
    log_file = open("log_file.csv", "w")
    fieldnames = ['INPUT TEXT', 'OUTPUT TEXT', 'WRITE TIME', 'READ TIME' ,'ALT TEXT DISTANCE','IMAGE SIMILARITY']
    writer = csv.DictWriter(log_file, fieldnames=fieldnames)
    writer.writeheader()
    #output_dict={}
    with open('images_alt_dataset.csv','r') as csvfile: 
        reader = csv.DictReader(csvfile, delimiter=',')
        i=0
        for row in reader:
          try:
            output=[]
            url=row['IMAGE URL']
            h=row['IMG Height']
            w=row['IMG Width']
            alt_in=row['ALT Text']
            
            if((int(h)>=50 and int(w)>=50) and alt_in!=''):
            #if(1):
                output.append(alt_in)
                #log_file.write(alt_in);
                #output.append
                print alt_in
                #print h + "X" + w
                i=str(i)
                img= str(i) + ".png"
                output_image_path= "images/" + str(i) + "_d" + ".png"
                print output_image_path
                i=int(i)
                i=i+1
                img="images/"+img
                f = open(img,'wb')
                f.write(requests.get(url,proxies=proxies).content)
                f.close()
                input_image_path=img;
                print input_image_path
                #out_img=img + "001"
                start_time = time.time()
                normalize(input_image_path, output_image_path)
                #hide_text(output_image_path, alt_in)
                #normalize(img)
                hide_text(output_image_path, alt_in)
                end_time=time.time()
                write_time=end_time - start_time

                start_time = time.time()    
                alt_out=read_text(output_image_path)
                end_time=time.time()
                read_time=end_time - start_time         # returns time taken by the fuction to execute in seconds
                #print alt_out
                jaro_dist=jellyfish.jaro_winkler(unicode(alt_in),unicode(alt_out)) # Distance between text written and text read
                #output_dict.update({'INPUT TEXT': alt_in, 'OUTPUT TEXT':alt_out, 'DISTANCE': }) # Write to dictionary
                ################### Calculate input and output image similarity #####################
                
                cmd="pyssim "+ input_image_path + " " + output_image_path
                ssim=os.popen(cmd).read()
                ssim=float(ssim)
                #print ssim
                #img_similarity = ssim(imageA, imageB)
                #print img_similarity
                #####################################################################################
                writer.writerow({'INPUT TEXT': alt_in, 'OUTPUT TEXT': alt_out, 'WRITE TIME': write_time, 'READ TIME': read_time, 'ALT TEXT DISTANCE': jaro_dist, 'IMAGE SIMILARITY':ssim})      # Write to log file
                #print jaro_dist
          except:
            continue
        print i    
    f1.close()

if __name__ == "__main__":
    main()